#include "State.h"
#include "Transition.h"

#ifndef AUTOMATON
#define AUTOMATON

#ifdef __cplusplus
extern "C" {
#endif
/** Automaton
 * Q = finite set of states
 * q0 = start state
 * F = finite set of final states
 * alphabet = input chars
 * C = set of clocks
 * T = set of transitions
 * */
typedef struct AUTOMATON {
	State* Q[3];
	State* q0;
	State* F[1];
	char alphabet[2];
	Transition* T[6];
} Automaton;

/** initAutomaton
 * initialize all Automaton data members
 * create and return the new automaton
 * */
Automaton* initAutomaton();

/** transition
 * given a state, input char, and set of all transitions - return the destination state
 * */
State* transition(State* q, char input, Transition* transitions[]);
#ifdef __cplusplus
}
#endif

#endif
