#include <stdio.h>
#include "Transition.h"
#include "State.h"

void initTransition(Transition* trans, State* s, State* d, char input) {
	trans->src = s;
	trans->dest = d;
	trans->input = input;
}
