#include <stdio.h>
#include "State.h"

void initState(State* state, int isStart, int isFinal, int isCurrent) {
	state->isStart   = isStart;
	state->isFinal   = isFinal;
	state->isCurrent = isCurrent;
}

