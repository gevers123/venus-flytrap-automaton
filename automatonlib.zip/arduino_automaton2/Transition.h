#include "State.h"

#ifndef TRANSITION
#define TRANSITION

#ifdef __cplusplus
extern "C" {
#endif

/** Transition
 * src   = source state
 * dest  = destination state
 * input = input char
 * */
typedef struct TRANSITION {
	State* src;
	State* dest;
	char input;
} Transition;

/** initTransition
 * initializes the transition with given src, dest, and input values
 * */
void initTransition(Transition* trans, State* s, State* d, char input);

#ifdef __cplusplus
}
#endif

#endif
