#ifndef STATE
#define STATE

#ifdef __cplusplus
extern "C" {
#endif

/** State
 * isStart = indicates if the state is a start state or not
 * isFinal = indicates if the state is a final state or not
 * isCurrent = indicates if the state is the current state or not
 * clock = the clock assigned to the state
 * */
typedef struct STATE {
	int isStart;
	int isFinal;
	int isCurrent;
} State;

/** initState
 * initializes the state with given isStart, isFinal, isCurrent, and clock values
 * */
void initState(State* state, int isStart, int isFinal, int isCurrent);

/** startTimer
 * if the state's clock is not NULL, then call startClock()
 * */
#ifdef __cplusplus
}
#endif

#endif
