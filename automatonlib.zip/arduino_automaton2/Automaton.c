#include <stdlib.h>
#include <stdio.h>
#include "State.h"
#include "Transition.h"
#include "Automaton.h"

Automaton* initAutomaton() {
	State* q0 = (State*)malloc(sizeof(State));	
	State* q1 = (State*)malloc(sizeof(State));
	State* q2 = (State*)malloc(sizeof(State));

	Transition* t1Q0 = (Transition*)malloc(sizeof(Transition));
	initTransition(t1Q0, q0, q1, '1');
	Transition* t2Q0 = (Transition*)malloc(sizeof(Transition));
	initTransition(t2Q0, q0, q0, '0');

	Transition* t1Q1 = (Transition*)malloc(sizeof(Transition));
	initTransition(t1Q1, q1, q2, '1');
	Transition* t2Q1 = (Transition*)malloc(sizeof(Transition));
	initTransition(t2Q1, q1, q0, '0');

	Transition* t1Q2 = (Transition*)malloc(sizeof(Transition));
	initTransition(t1Q2, q2, q2, '1');
	Transition* t2Q2 = (Transition*)malloc(sizeof(Transition));
	initTransition(t2Q2, q2, q0, '0');

	
	initState(q0, 1, 0, 1);
	initState(q1, 0, 0, 0);
	initState(q2, 0, 1, 0);

	Automaton* automaton = (Automaton*)malloc(sizeof(Automaton));
	automaton->Q[0] = q0;
	automaton->Q[1] = q1;
	automaton->Q[2] = q2;
	automaton->q0 = q0;
	automaton->F[0] = q2;
	automaton->alphabet[0] = '1';
	automaton->alphabet[1] = '0';
	automaton->T[0] = t1Q0;	
	automaton->T[1] = t2Q0;	
	automaton->T[2] = t1Q1;	
	automaton->T[3] = t2Q1;	
	automaton->T[4] = t1Q2;	
	automaton->T[5] = t2Q2;	

	return automaton;
}

State* transition(State* q, char input, Transition* transitions[]) {
	int size = 6;
	State* result = q;
	for(int i = 0; i < size; i++)
		if(transitions[i]->src == q && transitions[i]->input == input)
		{
			result = transitions[i]->dest;
			if(result != q)
			{
				result->isCurrent = 1;
				q->isCurrent      = 0;
			}
			return result;
		}
	return result;
}
